package com.green.company.project1.service;

import com.green.company.project1.domain.Todo;
import com.green.company.project1.dto.TodoDTO;
import com.green.company.project1.repository.TodoRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional//ACID (Atomic ,Consistency, Isolation(독립성) , Durablity)
@Slf4j
@RequiredArgsConstructor
public class TodoServiceImpl implements  TodoService{
//    @Autowired
//    private ModelMapper modelMapper;
    private final ModelMapper modelMapper;
    private final TodoRepository todoRepository;

    @Override
    public Long register(TodoDTO todoDTO) {
        log.info("todo service ------------------");
        Todo todo=modelMapper.map(todoDTO, Todo.class);
        Todo savedTodo = todoRepository.save(todo);
        return savedTodo.getTno();
    }
}
