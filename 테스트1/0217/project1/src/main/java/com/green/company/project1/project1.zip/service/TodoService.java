package com.green.company.project1.service;

import com.green.company.project1.dto.TodoDTO;

public interface TodoService {
    Long register(TodoDTO todoDTO);
}
